% Figure 5 code
clc
clear
close all

global Lambda betaU epsilonD epsilonT d mu1 mu2 mu3 tau deltan deltaa p nu1 phi

%parameter and initial values
S0=100000;
d=0.0149;  
Lambda=d*S0;
mu1=0;   % assumed
deltan=0.1;  % Xiao
deltaa=0.15;  %  assumed
tau=0.8;  % assumed
mu2=0.1; %Xiao
mu3=0.03; % Shen  Proceeding
nu1=0.1; %assumed
phi=0.3;  %assumed
p=0.3;    
betaU=0.25;
epsilonD=0.556; %  ��1-0.717��/(1-0.491)
epsilonT= 0.1095;  % 0.556*(1-0.803) Kang ruihua Ruan yuhua

U0=1000;D0=100;T0=100;M10=100;xx0=0.8;


y0=[S0,U0,D0,T0,M10,xx0];

mm1=0.001:0.001:0.01;
mm2=0.02:0.005:0.08;
mm3=0.09:0.01:0.15;
mm4=0.16:0.01:0.2;
mm=[mm1,mm2,mm3,mm4];
T_u=zeros(1,length(mm));
T_l=zeros(1,length(mm));
U_u=zeros(1,length(mm));
U_l=zeros(1,length(mm));
D_u=zeros(1,length(mm));
D_l=zeros(1,length(mm));
x_u=zeros(1,length(mm));
x_l=zeros(1,length(mm));
R_u=zeros(1,length(mm));
R_l=zeros(1,length(mm));

for i=1:length(mm)
    m=mm(i);
    tend=2000;
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    sol= ode45(@fun_behavior2,[0 tend],y0,options,m);
    xx=sol.y(6,:);

    NN=sol.y(1,:)+sol.y(2,:)+sol.y(3,:)+sol.y(4,:);


    R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol.y(1,:)./NN...
        +betaU*epsilonD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol.y(1,:)./NN...
        +betaU*epsilonT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol.y(1,:)./NN;

    
    ll=length(sol.x);  
    T_u(i)=max(sol.y(4,round(4*ll/5):ll));  % maximum value of T
    T_l(i)=min(sol.y(4,round(4*ll/5):ll));  % minimum value of T
    
    U_u(i)=max(sol.y(2,round(4*ll/5):ll));  % maximum value of U
    U_l(i)=min(sol.y(2,round(4*ll/5):ll));  % minimum value of U

    D_u(i)=max(sol.y(3,round(4*ll/5):ll));  % maximum value of D
    D_l(i)=min(sol.y(3,round(4*ll/5):ll));  % minimum value of D

    
    x_u(i)=max(sol.y(6,round(4*ll/5):ll));  % maximum value of x
    x_l(i)=min(sol.y(6,round(4*ll/5):ll));  % minimum value of x
    
    R_u(i)=max(R0_t(round(4*ll/5):ll));  % maximum value of Rt
    R_l(i)=min(R0_t(round(4*ll/5):ll));  % minimum value of Rt

end

figure
subplot(131)
hold on
plot(mm,U_u-U_l,'r','LineWidth',2)
plot(mm,D_u-D_l,'r','LineWidth',2)
plot(mm,T_u-T_l,'k','LineWidth',2)
xlabel('1/m')
ylabel('Amplitude')
legend('U(t)','D(t)','T(t)')
box on
title('(a)')
axis square
subplot(132)
hold on
plot(mm,x_u-x_l,'r','LineWidth',2)
plot(mm,R_u-R_l,'k','LineWidth',2)
xlabel('1/m')
ylabel('Amplitude')
legend('x(t)','R_t(t)')
box on
title('(b)')
axis square



mm1=0.001:0.001:0.01;
mm2=0.02:0.005:0.08;
mm3=0.09:0.01:0.15;
mm4=0.16:0.01:0.2;
mm=[mm1,mm2,mm3,mm4];

p=0.1;             

T_u=zeros(1,length(mm));
T_l=zeros(1,length(mm));
x_u=zeros(1,length(mm));
x_l=zeros(1,length(mm));


for i=1:length(mm)
    m=mm(i);
    tend=10000;
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    sol= ode45(@fun_behavior2,[0 tend],y0,options,m);

    
    ll=length(sol.x);  
    T_u(i)=max(sol.y(4,round(4*ll/5):ll));  
    T_l(i)=min(sol.y(4,round(4*ll/5):ll)); 
    
  
    x_u(i)=max(sol.y(6,round(4*ll/5):ll)); 
    x_l(i)=min(sol.y(6,round(4*ll/5):ll));  
    
end

figure(1)
subplot(133)
hold on
plot(mm,T_u-T_l,'k','LineWidth',2)
xlabel('1/m')
ylabel('Amplitude (T(t))')
box on
title('(c)')
axis square


%%
p=0.3;             
T_u=zeros(1,length(mm));
T_l=zeros(1,length(mm));

x_u=zeros(1,length(mm));
x_l=zeros(1,length(mm));


for i=1:length(mm)
    m=mm(i);
    tend=10000;
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    sol= ode45(@fun_behavior2,[0 tend],y0,options,m);
   
    ll=length(sol.x);  
    T_u(i)=max(sol.y(4,round(4*ll/5):ll));  
    T_l(i)=min(sol.y(4,round(4*ll/5):ll));  
    
    
    x_u(i)=max(sol.y(6,round(4*ll/5):ll));  
    x_l(i)=min(sol.y(6,round(4*ll/5):ll));  
    

end

figure(1)
subplot(133)
hold on

plot(mm,T_u-T_l,'r','LineWidth',2)
xlabel('1/m')


%%
p=0.4;              
T_u=zeros(1,length(mm));
T_l=zeros(1,length(mm));

x_u=zeros(1,length(mm));
x_l=zeros(1,length(mm));


for i=1:length(mm)
    m=mm(i);
    tend=10000;
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    sol= ode45(@fun_behavior2,[0 tend],y0,options,m);
  
    ll=length(sol.x); 
    T_u(i)=max(sol.y(4,round(4*ll/5):ll)); 
    T_l(i)=min(sol.y(4,round(4*ll/5):ll));  
    
   
    x_u(i)=max(sol.y(6,round(4*ll/5):ll));  
    x_l(i)=min(sol.y(6,round(4*ll/5):ll)); 
    

end

figure(1)
subplot(133)
hold on
plot(mm,T_u-T_l,'b','LineWidth',2)


%%
p=0.5;            

T_u=zeros(1,length(mm));
T_l=zeros(1,length(mm));

x_u=zeros(1,length(mm));
x_l=zeros(1,length(mm));


for i=1:length(mm)
    m=mm(i);
    tend=10000;
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    sol= ode45(@fun_behavior2,[0 tend],y0,options,m);

    
    ll=length(sol.x);  
    T_u(i)=max(sol.y(4,round(4*ll/5):ll));  
    T_l(i)=min(sol.y(4,round(4*ll/5):ll));  
    

    
    x_u(i)=max(sol.y(6,round(4*ll/5):ll));  
    x_l(i)=min(sol.y(6,round(4*ll/5):ll));  
    


end

figure(1)
subplot(133)
hold on

plot(mm,T_u-T_l,'g','LineWidth',2)

legend('p=0.1','p=0.3','p=0.4','p=0.5')