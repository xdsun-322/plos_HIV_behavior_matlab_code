function dy=fun_behavior(t,x)

global Lambda betaU epsilonD epsilonT d mu1 mu2 mu3 tau deltan deltaa p nu1 phi m

betaD=betaU*epsilonD;
betaT=betaU*epsilonT;

dy=zeros(6,1);

S=x(1); 
U=x(2);
D=x(3);
T=x(4);
M1=x(5);
xx=x(6);

N=S+U+D+T;

dy(1)=Lambda-(xx+p*(1-xx))*betaU*(xx+p*(1-xx))*S*U/N-(xx+p*(1-xx))*betaD*S*D/N-(xx+p*(1-xx))*betaT*S*T/N-d*S;
dy(2)=(xx+p*(1-xx))*betaU*(xx+p*(1-xx))*S*U/N+(xx+p*(1-xx))*betaD*S*D/N+(xx+p*(1-xx))*betaT*S*T/N-(deltan*xx+deltaa*(1-xx))*U-(mu1+d)*U;
dy(3)=(deltan*xx+deltaa*(1-xx))*U-tau*D-(mu2+d)*D;
dy(4)=tau*D-(mu3+d)*T;
dy(5)=(deltan*xx+deltaa*(1-xx))*U-nu1*M1;
dy(6)=(1-xx)*Lambda/(S+U)-(deltan-deltaa)*xx*(1-xx)*U/(S+U)+phi*xx*(1-xx)*(1-m*M1/N)*(S+U)/N;
