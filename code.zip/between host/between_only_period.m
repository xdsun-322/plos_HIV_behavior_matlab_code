% Figure 2 code
clc
clear
close all

global Lambda betaU epsilonD epsilonT d mu1 mu2 mu3 tau deltan deltaa p nu1 phi m

% parameter and initial values
S0=100000;
d=0.0149;  
Lambda=d*S0;
mu1=0;   % assumed
deltan=0.1;  % assumed
deltaa=0.15;  %assumed
tau=0.8;  % assumed
mu2=0.1; %Xiao
mu3=0.03; % Shen  Proceeding
nu1=0.1; %assumed
phi=0.3;  %assumed
p=0.3;    

betaU=0.25;
epsilonD=0.556;  %��1-0.717��/(1-0.491)
epsilonT= 0.1095;  % 0.556*(1-0.803) Kang ruihua Ruan yuhua

U0=1000;D0=100;T0=100;M10=100;xx0=0.8;


y0=[S0,U0,D0,T0,M10,xx0];

R0n=betaU/(deltan++mu1+d)...
    +betaU*epsilonD*deltan./((deltan+mu1+d)*(tau+mu2+d))...
    +betaU*epsilonT*tau*deltan/((deltan+mu1+d).*(tau+mu2+d).*(mu3+d))

R0a=betaU*p^2/(deltaa++mu1+d)...
    +p*betaU*epsilonD*deltaa./((deltaa+mu1+d)*(tau+mu2+d))...
    +p*betaU*epsilonT*tau*deltaa/((deltaa+mu1+d).*(tau+mu2+d).*(mu3+d))

%%

m=1/0.01; %periodic solution

tend=500;
options = odeset('RelTol',1e-6,'AbsTol',1e-6);
sol= ode45(@fun_behavior,[0 tend],y0,options);

xx=sol.y(6,:);

NN=sol.y(1,:)+sol.y(2,:)+sol.y(3,:)+sol.y(4,:);


R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol.y(1,:)./NN...
    +betaU*epsilonD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol.y(1,:)./NN...
    +betaU*epsilonT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol.y(1,:)./NN;

figure(1)

subplot(2,2,[1,2])
hold on
hold on
yyaxis left
plot(sol.x,sol.y(5,:)./NN,'b','LineWidth',1.5)
plot(sol.x,1/m*ones(size(sol.x)),'k--','LineWidth',1.5)
xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of infection'})
box on

yyaxis right
plot(sol.x,sol.y(6,:),'r','LineWidth',1.5)
xlabel('Time(years)')
ylabel({'Proportion of normal', 'behaviors'})
box on
title('(a)')

subplot(223)
hold on
plot(sol.x,sol.y(2,:)+sol.y(3,:)+sol.y(4,:),'k','LineWidth',1.5)
xlabel('Time(years)')
ylabel({'Number of HIV/AIDS','cases'})
axis([0 500 0 10000])
title('(b)')
box on

subplot(224)
hold on
plot(sol.x,R0_t,'k','LineWidth',1.5)
xlabel('Time(years)')
ylabel({'Effective reproduction', 'number'})
axis([0 500 0 2.5])
title('(c)')
box on
