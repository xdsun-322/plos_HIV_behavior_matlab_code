% Figure 13 code

clc
clear
close all

global Lambda bU0 mu0 epsilonD epsilonT d mu1 tau deltan deltaa p nu1 nu2 phi m A k delta zeta Nz c IC50_1 IC50_2 aa 

%parameter and initial values?
S0=100000;
d=0.0149;  % Xiao
Lambda=d*S0;
mu1=0;         % assumed
deltan=0.15;  %? Xiao
deltaa=0.25;  %?  assumed
tau=0.8;  % assumed
nu1=0.1; %assumed
nu2=0.2; %assumed
phi=0.3;  %assumed
p=0.1;        




epsilonD=0.556; % tan
epsilonT= 0.1095;  % 0.556*(1-0.803) Kang ruihua Ruan yuhua
mu0=10^-5;


%within-host parameters

A=12;k=2.4*10^-6;delta=0.01;zeta=1;Nz=3500;c=3;


aa=0.005;




nyear=500;
tend=365*nyear;



%%
m=20;
IC50_1=0.5;IC50_2=0.5;


U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];



options = odeset('RelTol',1e-15,'AbsTol',1e-15);

sol1= ode45(@fun_within_between,[0 tend],y0,options);

bmax=0.317;
bk=1.02;
b50=13938;



%%
m=20;
IC50_1=0.05;IC50_2=0.05;


U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-15,'AbsTol',1e-15);

sol2= ode45(@fun_within_between,[0 tend],y0,options);


%%

m=100;

IC50_1=0.05;IC50_2=0.05;


U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-15,'AbsTol',1e-15);

sol3= ode45(@fun_within_between,[0 tend],y0,options);



%%

m=100;

IC50_1=0.5;IC50_2=0.5;


U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-15,'AbsTol',1e-15);

sol4= ode45(@fun_within_between,[0 tend],y0,options);




%%


betaU=bmax.*sol1.y(10,:).^bk./(sol1.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol1.y(13,:).^bk./(sol1.y(13,:).^bk+b50^bk);

mu2=mu0*sol1.y(10,:);
mu3=mu0*sol1.y(13,:);


M2=sol1.y(6,:);
xx=sol1.y(7,:);

NN=sol1.y(1,:)+sol1.y(2,:)+sol1.y(3,:)+sol1.y(4,:);

   
R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol1.y(1,:)./NN...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol1.y(1,:)./NN...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol1.y(1,:)./NN;

R0_U=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol1.y(1,:)./NN;
R0_D=betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol1.y(1,:)./NN;
R0_T=betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol1.y(1,:)./NN;


x0=0:1:tend;
y=deval(sol1,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);  

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


varphi=1;
m2=M2./NN;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;


figure(1)
subplot(2,4,1)
hold on
plot(1:nyear,Newinfection,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel('New infections')
title('(a)')
box on
subplot(2,4,2)
hold on
plot(sol1.x./365,R0_t,'k','Linewidth',1.5)
plot(sol1.x./365,R0_U,'m','Linewidth',1.5)
plot(sol1.x./365,R0_D,'b','Linewidth',1.5)
plot(sol1.x./365,R0_T,'r','Linewidth',1.5)
xlabel('Time(years)')
ylabel('Effective reproduction number')
box on
title('(b)')
subplot(2,4,3)
hold on
plot(sol1.x./365,sol1.y(7,:),'k','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Proportion of normal';'behaviors'})
title('(c)')
box on
subplot(244)
hold on
plot(sol1.x./365,sol1.y(8,:),'m','Linewidth',1.5)
plot(sol1.x./365,sol1.y(11,:),'k','Linewidth',1.5)
box on
ylabel('Uninfected cells/\mul')
xlabel('t(years)')

title('(d)')


betaU=bmax.*sol2.y(10,:).^bk./(sol2.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol2.y(13,:).^bk./(sol2.y(13,:).^bk+b50^bk);

mu2=mu0*sol2.y(10,:);
mu3=mu0*sol2.y(13,:);


M2=sol2.y(6,:);
xx=sol2.y(7,:);

NN=sol2.y(1,:)+sol2.y(2,:)+sol2.y(3,:)+sol2.y(4,:);



R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol2.y(1,:)./NN...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol2.y(1,:)./NN...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol2.y(1,:)./NN;

R0_U=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol2.y(1,:)./NN;
R0_D=betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol2.y(1,:)./NN;
R0_T=betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol2.y(1,:)./NN;


x0=0:1:tend;
y=deval(sol2,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   ?

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


varphi=1;
m2=M2./NN;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;



figure(1)
subplot(2,4,1)
hold on
plot(1:nyear,Newinfection,'k--','Linewidth',1.5)
box on
subplot(2,4,2)
hold on
plot(sol2.x./365,R0_t,'k--','Linewidth',1.5)
plot(sol2.x./365,R0_U,'m--','Linewidth',1.5)
plot(sol2.x./365,R0_D,'b--','Linewidth',1.5)
plot(sol2.x./365,R0_T,'r--','Linewidth',1.5)
box on
title('(b)')
subplot(2,4,3)
hold on
plot(sol2.x./365,sol2.y(7,:),'k--','Linewidth',1.5)
box on
subplot(244)
hold on
plot(sol2.x./365,sol2.y(11,:),'k--','Linewidth',1.5)

box on



betaU=bmax.*sol4.y(10,:).^bk./(sol4.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol4.y(13,:).^bk./(sol4.y(13,:).^bk+b50^bk);

mu2=mu0*sol4.y(10,:);
mu3=mu0*sol4.y(13,:);


M2=sol4.y(6,:);
xx=sol4.y(7,:);

NN=sol4.y(1,:)+sol4.y(2,:)+sol4.y(3,:)+sol4.y(4,:);
     
R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol4.y(1,:)./NN...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol4.y(1,:)./NN...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol4.y(1,:)./NN;

R0_U=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol4.y(1,:)./NN;
R0_D=betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol4.y(1,:)./NN;
R0_T=betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol4.y(1,:)./NN;


x0=0:1:tend;
y=deval(sol4,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


varphi=1;
m2=M2./NN;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;

figure(1)
subplot(2,4,5)
hold on
plot(1:nyear,Newinfection,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel('New infections')
title('(e)')
box on
subplot(2,4,6)
hold on
plot(sol4.x./365,R0_t,'k','Linewidth',1.5)
plot(sol4.x./365,R0_U,'m','Linewidth',1.5)
plot(sol4.x./365,R0_D,'b','Linewidth',1.5)
plot(sol4.x./365,R0_T,'r','Linewidth',1.5)

xlabel('Time(years)')
ylabel({'Effective reproduction';'number'})

box on
title('(f)')
subplot(2,4,7)
hold on
plot(sol4.x./365,sol4.y(7,:),'k','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Proportion of normal';'behaviors'})
title('(g)')
box on
subplot(248)
hold on

plot(sol1.x./365,sol1.y(8,:),'m','Linewidth',1.5)
plot(sol1.x./365,sol1.y(11,:),'k','Linewidth',1.5)
box on
ylabel('Uninfected cells/\mul')
xlabel('t(years)')

title('(h)')



betaU=bmax.*sol3.y(10,:).^bk./(sol3.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol3.y(13,:).^bk./(sol3.y(13,:).^bk+b50^bk);

mu2=mu0*sol3.y(10,:);
mu3=mu0*sol3.y(13,:);


M2=sol3.y(6,:);
xx=sol3.y(7,:);

NN=sol3.y(1,:)+sol3.y(2,:)+sol3.y(3,:)+sol3.y(4,:);


   
R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol3.y(1,:)./NN...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol3.y(1,:)./NN...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol3.y(1,:)./NN;

R0_U=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol3.y(1,:)./NN;
R0_D=betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol3.y(1,:)./NN;
R0_T=betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol3.y(1,:)./NN;


x0=0:1:tend;
y=deval(sol3,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   ?

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


varphi=1;
m2=M2./NN;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;
figure(1)
subplot(2,4,5)
hold on
plot(1:nyear,Newinfection,'k--','Linewidth',1.5)
legend('\phi=0.5','\phi=0.05')
box on
subplot(2,4,6)
hold on
plot(sol3.x./365,R0_t,'k--','Linewidth',1.5)
plot(sol3.x./365,R0_U,'m--','Linewidth',1.5)
plot(sol3.x./365,R0_D,'b--','Linewidth',1.5)
plot(sol3.x./365,R0_T,'r--','Linewidth',1.5)
box on
title('(b)')
subplot(2,4,7)
hold on
plot(sol3.x./365,sol3.y(7,:),'k--','Linewidth',1.5)
box on
subplot(248)
hold on
plot(sol3.x./365,sol3.y(11,:),'k--','Linewidth',1.5)

box on

save adherence_effect2