% Figure 6 code

clc
clear
close all

global Lambda bU0 mu0 epsilonD epsilonT d mu1 tau deltan deltaa p nu1 nu2 phi m A k delta zeta Nz c IC50_1 IC50_2 aa 

%parameter and initial values
S0=100000;
d=0.0149;  % Xiao
Lambda=d*S0;
mu1=0;         % assumed
deltan=0.1;  % Xiao
deltaa=0.15;  %  assumed
tau=0.8;  % assumed

nu1=0.1; %assumed
nu2=0.2; %assumed
phi=0.3;  %assumed
p=0.1;        
m=60;


epsilonD=0.556; % tan ��1-0.717��/(1-0.491)
epsilonT= 0.1095;  % 0.556*(1-0.803) Kang ruihua Ruan yuhua


mu0=10^-5;


%within-host parameters

A=12;k=2.4*10^-6;delta=0.01;zeta=1;Nz=3500;c=3;
IC50_1=0.5;IC50_2=0.5;
  


nyear=1000;
tend=365*nyear;

%%
aa=0.1;

U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-10,'AbsTol',1e-10);
sol1= ode23(@fun_within_between,[0 tend],y0,options);
bmax=0.317;
bk=1.02;
b50=13938;

betaU=bmax.*sol1.y(10,:).^bk./(sol1.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol1.y(13,:).^bk./(sol1.y(13,:).^bk+b50^bk);

mu2=mu0*sol1.y(10,:);
mu3=mu0*sol1.y(13,:);


M2=sol1.y(6,:);
xx=sol1.y(7,:);

NN1=sol1.y(1,:)+sol1.y(2,:)+sol1.y(3,:)+sol1.y(4,:);



R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol1.y(1,:)./NN1...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol1.y(1,:)./NN1...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol1.y(1,:)./NN1;

x0=0:1:tend;
y=deval(sol1,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   %ÿ���¸�Ⱦ����

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


figure(1)
subplot(2,4,1)
hold on

plot(1:nyear,Newinfection,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel('New infections')
title('(a)')
box on

subplot(2,4,2)
hold on
plot(sol1.x./365,sol1.y(5,:)./NN1,'k','LineWidth',1.5)%,sol.x,sol.y(3,:),'b')%,sol.x,sol.y(4,:),'k')
plot(sol1.x./365,1/m*ones(size(sol1.x)),'k--','LineWidth',1.5)
xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of infection'})
box on
title('(b)')

subplot(2,4,3)
hold on
plot(sol1.x./365,sol1.y(6,:)./NN1,'k','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of deaths'})
title('(c)')
box on
subplot(2,4,4)
hold on
plot(sol1.x./365,sol1.y(7,:),'k','Linewidth',1.5)
xlabel('Time(years)')
ylabel('Proportion of normal behaviors')
title('(d)')
box on


figure(1)
subplot(245)
hold on
plot(sol1.x./365,sol1.y(8,:),'m','Linewidth',1.5)
plot(sol1.x./365,sol1.y(11,:),'k','Linewidth',1.5)
box on
ylabel('Uninfected cells/\mul')
xlabel('t(years)')
title('(e)')

subplot(246)
hold on
plot(sol1.x./365,log10(sol1.y(10,:)),'m','Linewidth',1.5)
plot(sol1.x./365,log10(sol1.y(13,:)),'k','Linewidth',1.5)

box on
ylabel('log10 RNA copies/ml')
xlabel('t(years)')
title('(f)')



varphi=1;
m2=M2./NN1;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;


figure(1)
subplot(247)
hold on
plot(sol1.x./365,At,'k','Linewidth',1.5)
box on
ylabel('Adherence')
xlabel('t(years)')
title('(g)')

subplot(248)
hold on
plot(sol1.x./365,eta1,'k','Linewidth',1.5)
box on
ylabel('Drug efficacy')
xlabel('t(years)')
title('(h)')



%%
aa=0.06;



U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-10,'AbsTol',1e-10);

sol2= ode23(@fun_within_between,[0 tend],y0,options);



betaU=bmax.*sol2.y(10,:).^bk./(sol2.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol2.y(13,:).^bk./(sol2.y(13,:).^bk+b50^bk);

mu2=mu0*sol2.y(10,:);
mu3=mu0*sol2.y(13,:);


M2=sol2.y(6,:);
xx=sol2.y(7,:);


NN2=sol2.y(1,:)+sol2.y(2,:)+sol2.y(3,:)+sol2.y(4,:);


   
R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol2.y(1,:)./NN2...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol2.y(1,:)./NN2...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol2.y(1,:)./NN2;

x0=0:1:tend;
y=deval(sol2,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   %ÿ���¸�Ⱦ����

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


figure(1)
subplot(2,4,1)
hold on

plot(1:nyear,Newinfection,'r-','Linewidth',1.5)

title('(a)')
box on
subplot(2,4,2)
hold on
plot(sol2.x./365,sol2.y(5,:)./NN2,'r','LineWidth',1.5)%,sol.x,sol.y(3,:),'b')%,sol.x,sol.y(4,:),'k')

xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of infection'})
box on
subplot(2,4,3)
hold on
plot(sol2.x./365,sol2.y(6,:)./NN2,'r','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of deaths'})

title('(c)')
box on
subplot(2,4,4)
hold on
plot(sol2.x./365,sol2.y(7,:),'r','Linewidth',1.5)
xlabel('Time(years)')
ylabel('Proportion of normal behaviors')
title('(d)')
box on


figure(1)
subplot(245)
hold on

plot(sol2.x./365,sol2.y(11,:),'r','Linewidth',1.5)
box on
ylabel('Uninfected cells/\mul')
xlabel('t(years)')
title('(e)')

subplot(246)
hold on

plot(sol2.x./365,log10(sol2.y(13,:)),'r','Linewidth',1.5)

box on
ylabel('log10 RNA copies/ml')
xlabel('t(years)')
title('(f)')




varphi=1;
m2=M2./NN2;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;


figure(1)
subplot(247)
hold on
plot(sol2.x./365,At,'r','Linewidth',1.5)
box on
ylabel('Adherence')
xlabel('t(years)')
title('(g)')

subplot(248)
hold on
plot(sol2.x./365,eta1,'r','Linewidth',1.5)
box on
ylabel('Drug efficacy')
xlabel('t(years)')
title('(h)')


%%
aa=0.005;

U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];



options = odeset('RelTol',1e-10,'AbsTol',1e-10);

sol3= ode23(@fun_within_between,[0 tend],y0,options);

betaU=bmax.*sol3.y(10,:).^bk./(sol3.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol3.y(13,:).^bk./(sol3.y(13,:).^bk+b50^bk);

mu2=mu0*sol3.y(10,:);
mu3=mu0*sol3.y(13,:);


M2=sol3.y(6,:);
xx=sol3.y(7,:);

NN3=sol3.y(1,:)+sol3.y(2,:)+sol3.y(3,:)+sol3.y(4,:);


    
R0_t=betaU.*(xx+p*(1-xx)).^2./(deltan.*xx+deltaa.*(1-xx)+mu1+d).*sol3.y(1,:)./NN3...
+betaD.*(xx+p*(1-xx)).*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d)).*sol3.y(1,:)./NN3...
+betaT.*(xx+p*(1-xx))*tau.*(deltan.*xx+deltaa.*(1-xx))./((deltan.*xx+deltaa.*(1-xx)+mu1+d).*(tau+mu2+d).*(mu3+d)).*sol3.y(1,:)./NN3;


x0=0:1:tend;
y=deval(sol3,x0);

Newinf=y(14,2:end)+y(15,2:end)+y(16,2:end)-y(14,1:end-1)-y(15,1:end-1)-y(16,1:end-1);   %ÿ���¸�Ⱦ����

j=1;
Newinfection=zeros(1,nyear);
for i=0:365:365*(nyear-1)
    Newinfection(j)=sum(Newinf(i+1:i+365));
    j=j+1;
end


figure(1)
subplot(2,4,1)
hold on
)
plot(1:nyear,Newinfection,'b-','Linewidth',1.5)

title('(a)')
box on
subplot(2,4,2)
plot(sol3.x./365,sol3.y(5,:)./NN3,'b','LineWidth',1.5)%,sol.x,sol.y(3,:),'b')%,sol.x,sol.y(4,:),'k')

xlabel('Time(years)')
ylabel({'Perceived prevalence','about risk of infection'})
box on
subplot(2,4,3)
hold on
plot(sol3.x./365,sol3.y(6,:)./NN3,'b','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Perceived prevalence';'about risk of deaths'})
title('(c)')
box on
subplot(2,4,4)
hold on
plot(sol3.x./365,sol3.y(7,:),'b','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'Proportion of normal';'behaviors'})
title('(d)')
box on
legend('a=0.1','a=0.05','a=0.005')


figure(1)
subplot(245)
hold on

plot(sol3.x./365,sol3.y(11,:),'b','Linewidth',1.5)
box on
ylabel('Uninfected cells/\mul')
xlabel('t(years)')
title('(e)')

subplot(246)
hold on

plot(sol3.x./365,log10(sol3.y(13,:)),'b','Linewidth',1.5)

box on
ylabel('log10 RNA copies/ml')
xlabel('t(years)')
title('(f)')



varphi=1;
m2=M2./NN3;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;



figure(1)
subplot(247)
hold on
plot(sol3.x./365,At,'b','Linewidth',1.5)
box on
ylabel('Adherence')
xlabel('t(years)')
title('(g)')

subplot(248)
hold on
plot(sol3.x./365,eta1,'b','Linewidth',1.5)
box on
ylabel('Drug efficacy')
xlabel('t(years)')
title('(h)')
legend('a=0.1','a=0.06','a=0.005')

save within_between_effectofa_period2