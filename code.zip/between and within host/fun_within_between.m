function dx = fun_within_between(t,x)

global Lambda bU0 mu0 epsilonD epsilonT d mu1 tau deltan deltaa p nu1 nu2 phi m A k delta zeta Nz c IC50_1 IC50_2 aa 

varphi=1;
% xx=0.1;
dx=zeros(16,1);

S=x(1); U=x(2);D=x(3);T=x(4);M1=x(5);M2=x(6);xx=x(7);

T1=x(8);TT1=x(9);V1=x(10);
T2=x(11);TT2=x(12);V2=x(13);

N=S+U+D+T;


VV1=V1;
VV2=V2;

% if abs(V1)<10^-8
%     VV1=0;
% end
% 
% if abs(V2)<10^-8
%     VV2=0;
% end

bmax=0.317;
bk=1.02;
b50=13938;

betaU=bmax*VV1^bk/(VV1^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax*VV2^bk/(VV2^bk+b50^bk);
% 
% betaU=bU0*V1;
% betaD=epsilonD*bU0*V1;
% betaT=epsilonD*bU0*V2;
mu2=mu0*VV1;
mu3=mu0*VV2;

%between-host model
dx(1)=(Lambda-(xx+p*(1-xx))*betaU*(xx+p*(1-xx))*S*U/N-(xx+p*(1-xx))*betaD*S*D/N-(xx+p*(1-xx))*betaT*S*T/N-d*S)/365;
dx(2)=((xx+p*(1-xx))*betaU*(xx+p*(1-xx))*S*U/N+(xx+p*(1-xx))*betaD*S*D/N+(xx+p*(1-xx))*betaT*S*T/N-(deltan*xx+deltaa*(1-xx))*U-(mu1+d)*U)/365;
dx(3)=((deltan*xx+deltaa*(1-xx))*U-tau*D-(mu2+d)*D)/365;
dx(4)=(tau*D-(mu3+d)*T)/365;
dx(5)=((deltan*xx+deltaa*(1-xx))*U-nu1*M1)/365;
% dx(6)=((mu2+d)*D+(mu3+d)*T-nu2*M2)/365;
dx(6)=(mu2*D+mu3*T-nu2*M2)/365;
dx(7)=((1-xx)*Lambda/(S+U)-(deltan-deltaa)*xx*(1-xx)*U/(S+U)+phi*xx*(1-xx)*(1-m*M1/N)*(S+U)/N)/365;


%within-host model before ART
dx(8)=A-k*T1*V1-delta*T1;
dx(9)=k*T1*V1-zeta*TT1;
dx(10)=Nz*zeta*TT1-c*V1;

%within-host model after ART
% eta1=M2./(varphi*IC50_1*aa*N+varphi*IC50_1*M2+M2);
% eta2=M2./(varphi*IC50_2*aa*N+varphi*IC50_2*M2+M2);


m2=M2./N;
At=m2./(aa+m2);
eta1=At./(varphi*IC50_1+At);
eta2=eta1;

dx(11)=A-k*(1-eta1)*T2*V2-delta*T2;
dx(12)=k*(1-eta1)*T2*V2-zeta*TT2;
dx(13)=Nz*(1-eta2)*zeta*TT2-c*V2;

dx(14)=((xx+p*(1-xx))*betaU*(xx+p*(1-xx))*S*U/N)/365;
dx(15)=((xx+p*(1-xx))*betaD*S*D/N)/365;
dx(16)=((xx+p*(1-xx))*betaT*S*T/N)/365;



end