% Figure 8 code

clc
clear
close all

global Lambda mu0 epsilonD d mu1 tau deltan deltaa p nu1 nu2 phi m A k delta zeta Nz c IC50_1 IC50_2 aa 

%parameter and initial values
S0=100000;
d=0.0149;  % Xiao
Lambda=d*S0;
mu1=0;         % assumed
deltan=0.1;  % Xiao
deltaa=0.15;  %  assumed
tau=0.8;  % assumed
% mu2=0.172; %Xiao
% mu3=0.03; % Shen  Proceeding
nu1=0.1; %assumed
nu2=0.2; %assumed
phi=0.3;  %assumed
p=0.1;         
m=12;

epsilonD=0.556; % tan ��1-0.717��/(1-0.491)
mu0=10^-5;


%within-host parameters


A=12;k=2.4*10^-6;delta=0.01;zeta=1;Nz=3500;c=3;
IC50_1=0.5;IC50_2=0.5;



nyear=2000;
tend=365*nyear;


%%

aa=0.1;  

U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-10,'AbsTol',1e-10);

sol1= ode23(@fun_within_between,[0 tend],y0,options);


bmax=0.317;
bk=1.02;
b50=13938;

betaU1=bmax.*sol1.y(10,:).^bk./(sol1.y(10,:).^bk+b50^bk);
betaD1=epsilonD*betaU1;
betaT1=epsilonD*bmax.*sol1.y(13,:).^bk./(sol1.y(13,:).^bk+b50^bk);

mu2_1=mu0*sol1.y(10,:);
mu3_1=mu0*sol1.y(13,:);



xx1=sol1.y(7,:);

NN1=sol1.y(1,:)+sol1.y(2,:)+sol1.y(3,:)+sol1.y(4,:);

    
R0_t1=betaU1.*(xx1+p*(1-xx1)).^2./(deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*sol1.y(1,:)./NN1...
+betaD1.*(xx1+p*(1-xx1)).*(deltan.*xx1+deltaa.*(1-xx1))./((deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*(tau+mu2_1+d)).*sol1.y(1,:)./NN1...
+betaT1.*(xx1+p*(1-xx1))*tau.*(deltan.*xx1+deltaa.*(1-xx1))./((deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*(tau+mu2_1+d).*(mu3_1+d)).*sol1.y(1,:)./NN1;

R0_U1=betaU1.*(xx1+p*(1-xx1)).^2./(deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*sol1.y(1,:)./NN1;
R0_D1=betaD1.*(xx1+p*(1-xx1)).*(deltan.*xx1+deltaa.*(1-xx1))./((deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*(tau+mu2_1+d)).*sol1.y(1,:)./NN1;
R0_T1=betaT1.*(xx1+p*(1-xx1))*tau.*(deltan.*xx1+deltaa.*(1-xx1))./((deltan.*xx1+deltaa.*(1-xx1)+mu1+d).*(tau+mu2_1+d).*(mu3_1+d)).*sol1.y(1,:)./NN1;




x0=0:1:tend;
y1=deval(sol1,x0);

Newinf1=y1(14,2:end)+y1(15,2:end)+y1(16,2:end)-y1(14,1:end-1)-y1(15,1:end-1)-y1(16,1:end-1);   %daily new infected cases
Newinf_U1=y1(14,2:end)-y1(14,1:end-1);    %daily new infected cases
Newinf_D1=y1(15,2:end)-y1(15,1:end-1);    %daily new infected cases
Newinf_T1=y1(16,2:end)-y1(16,1:end-1);    %daily new infected cases


j=1;
Newinfection1=zeros(1,nyear);
Newinfection_U1=zeros(1,nyear);
Newinfection_D1=zeros(1,nyear);
Newinfection_T1=zeros(1,nyear);

for i=0:365:365*(nyear-1)
    Newinfection1(j)=sum(Newinf1(i+1:i+365));
    Newinfection_U1(j)=sum(Newinf_U1(i+1:i+365));
    Newinfection_D1(j)=sum(Newinf_D1(i+1:i+365));
    Newinfection_T1(j)=sum(Newinf_T1(i+1:i+365));
    j=j+1;
end


figure(1)
subplot(131)
plot(1:nyear,Newinfection_U1,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'New infections caused by'; 'undiagnosed cases'})
title('(a)')
box on
axis square


subplot(132)
plot(1:nyear,Newinfection_D1,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'New infections caused by';'diagnosed cases'})
title('(b)')
box on
axis square

subplot(133)
plot(1:nyear,Newinfection_T1,'k-','Linewidth',1.5)
xlabel('Time(years)')
ylabel({'New infections caused by';'cases with ART'})
title('(c)')
box on
axis square





%%

aa=0.06;

U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-10,'AbsTol',1e-10);

sol2= ode23(@fun_within_between,[0 tend],y0,options);



betaU2=bmax.*sol2.y(10,:).^bk./(sol2.y(10,:).^bk+b50^bk);
betaD2=epsilonD*betaU2;
betaT2=epsilonD*bmax.*sol2.y(13,:).^bk./(sol2.y(13,:).^bk+b50^bk);

mu2_2=mu0*sol2.y(10,:);
mu3_2=mu0*sol2.y(13,:);


xx2=sol2.y(7,:);

NN2=sol2.y(1,:)+sol2.y(2,:)+sol2.y(3,:)+sol2.y(4,:);


R0_t2=betaU2.*(xx2+p*(1-xx2)).^2./(deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*sol2.y(1,:)./NN2...
+betaD2.*(xx2+p*(1-xx2)).*(deltan.*xx2+deltaa.*(1-xx2))./((deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*(tau+mu2_2+d)).*sol2.y(1,:)./NN2...
+betaT2.*(xx2+p*(1-xx2))*tau.*(deltan.*xx2+deltaa.*(1-xx2))./((deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*(tau+mu2_2+d).*(mu3_2+d)).*sol2.y(1,:)./NN2;

R0_U2=betaU2.*(xx2+p*(1-xx2)).^2./(deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*sol2.y(1,:)./NN2;
R0_D2=betaD2.*(xx2+p*(1-xx2)).*(deltan.*xx2+deltaa.*(1-xx2))./((deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*(tau+mu2_2+d)).*sol2.y(1,:)./NN2;
R0_T2=betaT2.*(xx2+p*(1-xx2))*tau.*(deltan.*xx2+deltaa.*(1-xx2))./((deltan.*xx2+deltaa.*(1-xx2)+mu1+d).*(tau+mu2_2+d).*(mu3_2+d)).*sol2.y(1,:)./NN2;



x0=0:1:tend;
y2=deval(sol2,x0);

Newinf2=y2(14,2:end)+y2(15,2:end)+y2(16,2:end)-y2(14,1:end-1)-y2(15,1:end-1)-y2(16,1:end-1);   %ÿ���¸�Ⱦ����
Newinf_U2=y2(14,2:end)-y2(14,1:end-1);    %daily new infected cases
Newinf_D2=y2(15,2:end)-y2(15,1:end-1);    %daily new infected cases
Newinf_T2=y2(16,2:end)-y2(16,1:end-1);    %daily new infected cases


j=1;
Newinfection2=zeros(1,nyear);
Newinfection_U2=zeros(1,nyear);
Newinfection_D2=zeros(1,nyear);
Newinfection_T2=zeros(1,nyear);

for i=0:365:365*(nyear-1)
    Newinfection2(j)=sum(Newinf2(i+1:i+365));
    Newinfection_U2(j)=sum(Newinf_U2(i+1:i+365));
    Newinfection_D2(j)=sum(Newinf_D2(i+1:i+365));
    Newinfection_T2(j)=sum(Newinf_T2(i+1:i+365));
    j=j+1;
end


figure(1)
subplot(131)
hold on
plot(1:nyear,Newinfection_U2,'r-','Linewidth',1.5)


subplot(132)
hold on
plot(1:nyear,Newinfection_D2,'r-','Linewidth',1.5)


subplot(133)
hold on
plot(1:nyear,Newinfection_T2,'r-','Linewidth',1.5)




%%
aa=0.005;


U0=1000;D0=100;T0=100;M10=100;M20=10;xx0=0.8;
T10=1000;TT10=0;V10=100;
T20=1000;TT20=0;V20=100;

y0=[S0,U0,D0,T0,M10,M20,xx0,T10,TT10,V10,T20,TT20,V20,0,0,0];


options = odeset('RelTol',1e-10,'AbsTol',1e-10);

sol3= ode23(@fun_within_between,[0 tend],y0,options);



betaU=bmax.*sol3.y(10,:).^bk./(sol3.y(10,:).^bk+b50^bk);
betaD=epsilonD*betaU;
betaT=epsilonD*bmax.*sol3.y(13,:).^bk./(sol3.y(13,:).^bk+b50^bk);

mu2_1=mu0*sol3.y(10,:);
mu3_1=mu0*sol3.y(13,:);


xx3=sol3.y(7,:);

NN3=sol3.y(1,:)+sol3.y(2,:)+sol3.y(3,:)+sol3.y(4,:);


    
R0_t3=betaU.*(xx3+p*(1-xx3)).^2./(deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*sol3.y(1,:)./NN3...
+betaD.*(xx3+p*(1-xx3)).*(deltan.*xx3+deltaa.*(1-xx3))./((deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*(tau+mu2_1+d)).*sol3.y(1,:)./NN3...
+betaT.*(xx3+p*(1-xx3))*tau.*(deltan.*xx3+deltaa.*(1-xx3))./((deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*(tau+mu2_1+d).*(mu3_1+d)).*sol3.y(1,:)./NN3;

R0_U3=betaU.*(xx3+p*(1-xx3)).^2./(deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*sol3.y(1,:)./NN3;
R0_D3=betaD.*(xx3+p*(1-xx3)).*(deltan.*xx3+deltaa.*(1-xx3))./((deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*(tau+mu2_1+d)).*sol3.y(1,:)./NN3;
R0_T3=betaT.*(xx3+p*(1-xx3))*tau.*(deltan.*xx3+deltaa.*(1-xx3))./((deltan.*xx3+deltaa.*(1-xx3)+mu1+d).*(tau+mu2_1+d).*(mu3_1+d)).*sol3.y(1,:)./NN3;



x0=0:1:tend;
y3=deval(sol3,x0);

Newinf3=y3(14,2:end)+y3(15,2:end)+y3(16,2:end)-y3(14,1:end-1)-y3(15,1:end-1)-y3(16,1:end-1);   %ÿ���¸�Ⱦ����
Newinf_U3=y3(14,2:end)-y3(14,1:end-1);    %daily new infected cases
Newinf_D3=y3(15,2:end)-y3(15,1:end-1);    %daily new infected cases
Newinf_T3=y3(16,2:end)-y3(16,1:end-1);    %daily new infected cases


j=1;
Newinfection3=zeros(1,nyear);
Newinfection_U3=zeros(1,nyear);
Newinfection_D3=zeros(1,nyear);
Newinfection_T3=zeros(1,nyear);

for i=0:365:365*(nyear-1)
    Newinfection3(j)=sum(Newinf3(i+1:i+365));
    Newinfection_U3(j)=sum(Newinf_U3(i+1:i+365));
    Newinfection_D3(j)=sum(Newinf_D3(i+1:i+365));
    Newinfection_T3(j)=sum(Newinf_T3(i+1:i+365));
    j=j+1;
end

figure(1)
subplot(131)
hold on
plot(1:nyear,Newinfection_U3,'b-','Linewidth',1.5)


subplot(132)
hold on
plot(1:nyear,Newinfection_D3,'b-','Linewidth',1.5)


subplot(133)
hold on
plot(1:nyear,Newinfection_T3,'b-','Linewidth',1.5)

legend('a=0.1','a=0.06','a=0.005')



save compare_a_oscillate